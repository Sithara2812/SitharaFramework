Create a framework
Download selenium from Maven repository and add it in POM.xml under dependency tags
Download chromedriver - https://googlechromelabs.github.io/chrome-for-testing/#stable
Create a folder Browser and add chromedriver to it

