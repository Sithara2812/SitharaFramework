package seleniumFunctions;

public class readBrowserDriver {
	//no main method in java
	public void readBrowser() {

	}
}
